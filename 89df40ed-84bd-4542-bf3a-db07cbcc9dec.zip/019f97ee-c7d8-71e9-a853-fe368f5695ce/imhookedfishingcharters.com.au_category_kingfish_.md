---
url: "https://imhookedfishingcharters.com.au/category/kingfish/"
title: "Kingfish - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![How To Catch Kingfish – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/wp-content/uploads/2021/01/Yellowtail-Kingfish-Photo-400x250-1.png)](https://imhookedfishingcharters.com.au/how-to-catch-kingfish/)

## [How To Catch Kingfish – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/how-to-catch-kingfish/)

by [admin](https://imhookedfishingcharters.com.au/author/admin/ "Posts by admin") \| Jan 19, 2021 \| [Kingfish](https://imhookedfishingcharters.com.au/category/kingfish/)

When is (yellowtail) kingfish fishing season? A: January to April. The main kingfish fishing season begins in January either in or outside the heads on Port Phillip Bay and Westernport Bays. What is the minimum legal size of a kingfish you can keep? A: 60 cm What is...