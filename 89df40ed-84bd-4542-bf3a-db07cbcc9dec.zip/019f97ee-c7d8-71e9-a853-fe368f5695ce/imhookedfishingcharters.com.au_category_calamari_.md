---
url: "https://imhookedfishingcharters.com.au/category/calamari/"
title: "Calamari - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![How To Catch Squid – Top Advice](https://imhookedfishingcharters.com.au/wp-content/uploads/2020/09/squid-photo-400x250-1.png)](https://imhookedfishingcharters.com.au/how-to-catch-squid/)

## [How To Catch Squid – Top Advice](https://imhookedfishingcharters.com.au/how-to-catch-squid/)

by [Malcolm May](https://imhookedfishingcharters.com.au/author/mal/ "Posts by Malcolm May") \| Sep 1, 2020 \| [Calamari](https://imhookedfishingcharters.com.au/category/calamari/)

When Is Squid (Southern Calamari) fishing season? A: All year. What is the minimum legal size of a squid you can keep? A: No minimum What is the bag limit? A: 10 per angler  Can I collect squid in Marine National Parks and Sanctuaries? A: You can’t collect squid...