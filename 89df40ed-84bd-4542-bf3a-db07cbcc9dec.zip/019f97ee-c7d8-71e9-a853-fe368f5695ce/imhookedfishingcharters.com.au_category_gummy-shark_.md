---
url: "https://imhookedfishingcharters.com.au/category/gummy-shark/"
title: "Gummy Shark - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![Ultimate Shark Fishing Guide: How To Catch Shark](https://imhookedfishingcharters.com.au/wp-content/uploads/2023/02/ultimate-shark-fishing-guide-.jpg)](https://imhookedfishingcharters.com.au/ultimate-shark-fishing-guide/)

## [Ultimate Shark Fishing Guide: How To Catch Shark](https://imhookedfishingcharters.com.au/ultimate-shark-fishing-guide/)

by [admin](https://imhookedfishingcharters.com.au/author/admin/ "Posts by admin") \| Feb 10, 2023 \| [Shark](https://imhookedfishingcharters.com.au/category/shark/), [Gummy Shark](https://imhookedfishingcharters.com.au/category/gummy-shark/)

How To Catch Shark – FAQ’s When is Shark fishing season? A: In Victoria, outside the heads of Port Phillip Bay, the season is January to September. What is the minimum legal size of a Shark you can keep? Bronze Whaler, Port Jackson & Broadnose...
[![How To Catch Gummy Sharks – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/wp-content/uploads/2020/09/gummy-shark-photo-400x250-1.png)](https://imhookedfishingcharters.com.au/how-to-catch-gummy-sharks/)

## [How To Catch Gummy Sharks – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/how-to-catch-gummy-sharks/)

by [Malcolm May](https://imhookedfishingcharters.com.au/author/mal/ "Posts by Malcolm May") \| Sep 2, 2020 \| [Gummy Shark](https://imhookedfishingcharters.com.au/category/gummy-shark/)

How To Catch Gummy Sharks – FAQ’s When is gummy shark season? A: All year round What is the minimum legal size of a gummy shark you can keep? A: 45 cm What is the bag limit? A: A combined total limit of 2 for gummy shark and/or school shark. Can I fillet...