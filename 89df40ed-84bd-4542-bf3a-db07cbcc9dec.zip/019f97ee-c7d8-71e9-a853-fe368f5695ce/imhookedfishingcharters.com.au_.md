---
url: "https://imhookedfishingcharters.com.au/"
title: "Fishing Charter - Port Phillip Bay - Friendliest charter operator in Melbourne"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

# Fishing Charter

## Fun, friendly fishing charters for individuals or groups

[Book Now](https://imhookedfishingcharters.com.au/fishing-charter-bookings/#bookings)

## Over 40 Years Of Fishing Experience To Help You

Run by Mal, a qualified charter operator, who is passionate about fishing and brings a positive attitude to his charters. His customers describe the experience as **fun, f** **riendly and e** **njoyable**. Years of experience means Mal can bring you to the best fishing spots. He is happy to help beginner through to experienced anglers. ( [see reviews](https://g.page/r/CZflgfbW6XLfEB4/review))

### Take Me Straight To The Charters (Use buttons below)

[Snapper Charters Oct - Dec](https://imhookedfishingcharters.com.au/snapper-fishing-charters/)

[Offshore Charters - Tuna Shark Kingfish](https://imhookedfishingcharters.com.au/offshore-fishing/)

Victoria’s Best Fishing Spots!

## Fishing Charters



#### Port Phillip Bay



#### Western Port Bay



#### Bass straight

[Specials](https://imhookedfishingcharters.com.au/fishing-charter-specials/)

## Melbourne Fishing Charters

Our [fishing charters](https://imhookedfishingcharters.com.au/fishing-charter-bookings/) target assorted species in Port Phillip Bay, Western Port Bay, Bass Strait fishing grounds. The local Melbourne fishing charters are typically 5 to 6 hours in length, whilst offshore charters in Bass Straight are typically 7- 8 hours in length. One of the unique differences with an I’m Hooked Fishing Charter is the fun that Mal brings to the trip. Mal is known for bringing a smile and making the trip and enjoyable experience. From the inexperienced angler through to the seasoned fisho, Mal’s local knowledge and experience are what can transform a day into a memorable experience. Want to see how much fun people have? View the gallery by clicking the button below.

[Gallery](https://imhookedfishingcharters.com.au/gallery/)

![](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201224%201158'%3E%3C/svg%3E)

[![port phillip bay fishing charters](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20225%20155'%3E%3C/svg%3E)](https://imhookedfishingcharters.com.au/fishing-charter-port-phillip-bay/)

#### Fishing Charters Port Phillip Bay

[**Port Philip Bay**](https://imhookedfishingcharters.com.au/fishing-charter-port-phillip-bay/) is Victoria’s largest body of water and the state’s most popular recreational fishing ground which has a reputation for turning on some great fishing for snapper, flathead, King George whiting, garfish and squid.

[![western port bay fishing charters](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20225%20161'%3E%3C/svg%3E)](https://imhookedfishingcharters.com.au/fishing-charter-western-port-bay/)

#### Fishing Charters Western Port Bay

[**Western Port Bay**](https://imhookedfishingcharters.com.au/fishing-charter-western-port-bay/) is a smaller bay than Port Phillip Bay on the other side of the Mornington Peninsula, featuring two large islands, French and Phillip. There are three main areas of fishing; the northern, eastern and western arms. It offers great fishing with whiting, squid and snapper with the occasional gummy shark.

![Bass Straight Fishing Charters](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20225%20152'%3E%3C/svg%3E)

#### Fishing Charters Bass Straight

[**Bass Strait**](https://imhookedfishingcharters.com.au/product/offshore-fishing-charter/), a channel separating Victoria from Tasmania has a maximum width of 240 km and its depth is 50–70 m and named in 1798 after surgeon-explorer George Bass. There is great fishing for Mako Sharks, Flathead, Snapper, Whiting and Gummy Sharks.

Still not convinced that I’m Hooked Fishing Charters is the best value fishing charter in Melbourne? Why not check out Mal’s new charter boat. It has heaps of room and is **super comfortable.** Click on the button below to see some pics. (And yeah, it’s got a toilet ;-))

[View The Fishing Charter Boat](https://imhookedfishingcharters.com.au/the-fishing-charters-victoria-boat/)

## Fishing Charters

More options available on [Charters](https://imhookedfishingcharters.com.au/fishing-charter-bookings/) page

## **Fishing Charters Mornington Peninsula**

Min. 5 people. Max 8 people.

**Snapper or Whiting Charters**

Up to 5hrs $200 PER Person

Also available:

## **Reel Fishing Adventures in Bass Straight**

**Kingfish, Wrasse, Gummy Shark, Tuna Charters**

Up to 8hrs From $300 PER Person

\\* See Offshore Fishing Charters OR Book the Boat

![Fishing charter showing a great catch of Snapper](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20343'%3E%3C/svg%3E)

### Fishing charters available in Port Philip & Western Port Bays & offshore.

Are you looking for a genuine fishing trip with an experienced guide? Grab some friends and make a booking at let Mal guide you to the hottest spots!

## What Our Customers Say

Posted on Google

Stephanie Laratta

21\. March, 2026.

Trustindex verifies that the original source of the review is Google.

Thoroughly enjoyed the whole experience. Thank you Mal for a great morning!

Posted on Google

Daniel Wilton

31\. January, 2026.

Trustindex verifies that the original source of the review is Google.

My family and I great time fishing with Mal this morning on the 0500 charter. Mal was easily contactable with any questions we had before the trip and sent a reminder text night before the trip. Great sturdy fishing boat with really nice fishing rods. The fishing started slow as it was a slack tide but Mal knew all the places where fish might have tried to hide from us! Daniel, my son caught a huge Trevally right at the end of the trip and that absolutely made his day. Mal was the best boat captain! Helped my newbie fishing family with tips on how to cast and hook the bait and took the fish we caught off the hook. Would definitely recommend this charter for anyone looking for an amazing time on the water.

Posted on Google

Sam Brown

6\. January, 2026.

Trustindex verifies that the original source of the review is Google.

Had an awesome day on Westernport today - Mal is a legend! I had a charter booked with my kids a few months ago, but we had to postpone due to poor weather. Mal made it super easy to re-book the trip. He's a very safe and knowledgeable guide, and was all about getting us to the spots to find plenty of fish. A brilliant day out, would absolutely recommend Mal!

Posted on Google

Alana Jagas

30\. December, 2025.

Trustindex verifies that the original source of the review is Google.

Shoutout to Mal, I highly recommend his fishing charter!!! Mal is awesome and made the experience even better with his knowledge and great company. He's good at what he does and took us to some great spots. Looking forward to going back out there, thanks again Mal.

Posted on Google

Matthew Tambo

22\. December, 2025.

Trustindex verifies that the original source of the review is Google.

Fantastic day out on the water! Very comfortable boat to be on. Plenty of fish caught! Skipper put us straight on the fish couldn’t ask for much more. Highly recommend!

Posted on Google

suki su

22\. October, 2025.

Trustindex verifies that the original source of the review is Google.

Very patient with prompt response, Great fishing services with professional guidance, Highly recommend

Posted on Google

Jamal

29\. September, 2025.

Trustindex verifies that the original source of the review is Google.

Had an awesome time out yesterday with the family. Mal was very professional, experienced and helpful.
Got onto some pinkies, squid and whiting all in one session.
Highly recommended. Thanks again Mal!

Posted on Google

Dylan Mason

20\. September, 2025.

Trustindex verifies that the original source of the review is Google.

Had an awesome fishing trip with the family ! Thanks mal 🌟🌟🌟🌟🌟

Posted on Google

Aloysius Ng

28\. June, 2025.

Trustindex verifies that the original source of the review is Google.

Mal is THE MAN! This was the first fishing charter I've booked in Melbourne and I'm Hooked definitely delivered 😁 Had an absolute blast of a morning with my mates onboard Mal's boat. He was responsive, professional and made it his personal mission to ensure that everyone walked away happy. 💕 Our expectations weren't high as it was coming into the winter season, which is a slow time for majority of game species. So we were pretty surprised when we ended up with a ton of squid, more than enough to last all 7 of us for 3 whole weeks! 🦑 Every piece of gear and equipment we used was of utmost quality and the boat was clean and well-maintained. 🎣 I would highly recommend giving I'm Hooked charters a go if you're looking for a great time out in the open seas with your mates 😎

## Snapper Fishing Charters – Oct to Dec

Season: August to April. Our Snapper dedicated season is **October to December**. The main snapper fishing season begins in August (offshore), or in September in the bays (Western Port and Port Phillip), but snapper can be caught in winter. Outside of the dedicated Snapper season, please use our mixed charter option below. For more info [read here](https://imhookedfishingcharters.com.au/how-to-catch-snapper/)

Prices start from $200 p.p.

[Individual Bookings](https://imhookedfishingcharters.com.au/product/snapper-fishing-charter/)

[Group Bookings](https://imhookedfishingcharters.com.au/product/snapper-fishing-charter-book-boat/)

![Snapper Fishing Charter](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20250'%3E%3C/svg%3E)

![fishing charter melbourne snapper whiting calamari](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20400'%3E%3C/svg%3E)

## Snapper, Whiting & Calamari Fishing Charters

Season: All year. Mixed Fishing charters commence from **January 1st through to 30th September.** We fish according to which fish are biting at the time to try and make sure you bring home a good catch.

Prices start from $200 p.p.

[Individual Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter/)

[Group Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter-book-boat/)

## Squid Fishing Charters

Season: All year. For more info [read here](https://imhookedfishingcharters.com.au/how-to-catch-squid/)

Prices start from $200 p.p.

[Individual Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter/)

[Group Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter-book-boat/)

![squid fishing charter](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20250'%3E%3C/svg%3E)

![fishing charter melbourne whiting](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20285'%3E%3C/svg%3E)

## Whiting Fishing Charters

Season: Traditionally it is considered December to April. However, you can catch King George whiting all year round in our local waters within Western Port Bay and Port Phillip Bay. For more info [read here](https://imhookedfishingcharters.com.au/how-to-catch-whiting/)

Prices start from $200 p.p.

[Individual Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter/)

[Group Bookings](https://imhookedfishingcharters.com.au/product/snapper-whiting-squid-fishing-charter-book-boat/)

## Kingfish Fishing Charters

Season: January to April. The main kingfish fishing season begins in January either in or outside the heads on Port Phillip Bay and Westernport Bays. Kingfish Fishing charters commence from **January 18th.** For more info [read here](https://imhookedfishingcharters.com.au/how-to-catch-kingfish/)

Prices start from $2,400.

[Group Bookings (8)](https://imhookedfishingcharters.com.au/?post_type=product&p=5111)

![kingfish fishing charter](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20250'%3E%3C/svg%3E)

![fishing charter melbourne bluefin tuna](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20250'%3E%3C/svg%3E)

## Tuna Fishing Charters

Season: In Victoria, outside the heads of Port Phillip Bay, the season is February to September. Tuna Fishing charters commence from **January 18th**. For more info [read here](https://imhookedfishingcharters.com.au/how-to-catch-tuna/)

Prices start from $2,400.

[Group Bookings (8)](https://imhookedfishingcharters.com.au/product/offshore-fishing-charter-book-boat/)

[Individual Bookings (Min. 4)](https://imhookedfishingcharters.com.au/product/offshore-fishing-charter/)

![fishing charter melbourne shark](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20400%20285'%3E%3C/svg%3E)

## Shark Fishing Charters

Season: All year. Shark Fishing charters commence from **January 18th.** For more info on how to catch gummy sharks [read here](https://imhookedfishingcharters.com.au/how-to-catch-gummy-sharks/)

Prices start from $2,400.

[Group Bookings (8)](https://imhookedfishingcharters.com.au/product/offshore-fishing-charter-book-boat/)

## Exciting Catches Captured On Video

[Fishing Charter FAQ](https://imhookedfishingcharters.com.au/fishing-charter-faq/)

![Im Hooked Fishing Charters](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%20600%20202'%3E%3C/svg%3E)

## Want discounts and fishing tips?

Want the latest fishing news and charter specials from I'm Hooked Fishing Charters?

Get Tips & Discounts

## You have Successfully Subscribed!