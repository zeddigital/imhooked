---
url: "https://imhookedfishingcharters.com.au/category/snapper/"
title: "Snapper - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![How To Catch Snapper – Best Fishing Tips](https://imhookedfishingcharters.com.au/wp-content/uploads/2020/09/snapper-photo400x250.png)](https://imhookedfishingcharters.com.au/how-to-catch-snapper/)

## [How To Catch Snapper – Best Fishing Tips](https://imhookedfishingcharters.com.au/how-to-catch-snapper/)

by [Malcolm May](https://imhookedfishingcharters.com.au/author/mal/ "Posts by Malcolm May") \| Sep 1, 2020 \| [Snapper](https://imhookedfishingcharters.com.au/category/snapper/)

When is snapper fishing season? A: August to April. The main snapper fishing season begins in August (offshore), or in September in the bays (Western Port and Port Phillip), but snapper can be caught in winter. What is the minimum legal size of a snapper you can keep?...