---
url: "https://imhookedfishingcharters.com.au/category/whiting/"
title: "Whiting - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![How To Catch Whiting – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/wp-content/uploads/2021/08/whiting-photo-new-400x285-1.png)](https://imhookedfishingcharters.com.au/how-to-catch-whiting/)

## [How To Catch Whiting – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/how-to-catch-whiting/)

by [Malcolm May](https://imhookedfishingcharters.com.au/author/mal/ "Posts by Malcolm May") \| Sep 1, 2020 \| [Whiting](https://imhookedfishingcharters.com.au/category/whiting/)

How To Catch Whiting – FAQ’s When is King George Whiting season? A: Traditionally it is considered December to April. You can catch King George whiting all year round in our local waters within Western Port Bay and Port Phillip Bay, but as the months get...