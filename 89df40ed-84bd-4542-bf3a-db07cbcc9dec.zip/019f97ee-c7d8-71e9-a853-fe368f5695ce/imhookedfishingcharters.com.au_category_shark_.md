---
url: "https://imhookedfishingcharters.com.au/category/shark/"
title: "Shark - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![Ultimate Shark Fishing Guide: How To Catch Shark](https://imhookedfishingcharters.com.au/wp-content/uploads/2023/02/ultimate-shark-fishing-guide-.jpg)](https://imhookedfishingcharters.com.au/ultimate-shark-fishing-guide/)

## [Ultimate Shark Fishing Guide: How To Catch Shark](https://imhookedfishingcharters.com.au/ultimate-shark-fishing-guide/)

by [admin](https://imhookedfishingcharters.com.au/author/admin/ "Posts by admin") \| Feb 10, 2023 \| [Shark](https://imhookedfishingcharters.com.au/category/shark/), [Gummy Shark](https://imhookedfishingcharters.com.au/category/gummy-shark/)

How To Catch Shark – FAQ’s When is Shark fishing season? A: In Victoria, outside the heads of Port Phillip Bay, the season is January to September. What is the minimum legal size of a Shark you can keep? Bronze Whaler, Port Jackson & Broadnose...