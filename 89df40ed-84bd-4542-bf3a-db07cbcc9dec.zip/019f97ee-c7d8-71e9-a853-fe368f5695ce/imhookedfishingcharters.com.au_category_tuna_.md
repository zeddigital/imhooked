---
url: "https://imhookedfishingcharters.com.au/category/tuna/"
title: "Tuna - I'm Hooked Fishing Charters"
---

[0 Items](https://imhookedfishingcharters.com.au/cart/)

[![How To Catch Tuna – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/wp-content/uploads/2021/02/southern_bluefin_tuna-400x250-1.png)](https://imhookedfishingcharters.com.au/how-to-catch-tuna/)

## [How To Catch Tuna – Best Pro Fishing Tips](https://imhookedfishingcharters.com.au/how-to-catch-tuna/)

by [admin](https://imhookedfishingcharters.com.au/author/admin/ "Posts by admin") \| Feb 25, 2021 \| [Tuna](https://imhookedfishingcharters.com.au/category/tuna/)

How To Catch Tuna – FAQ’s When is Southern Bluefin Tuna fishing season? A: In Victoria, outside the heads of Port Phillip Bay, the season is February to May. When departing from Portland, Victoria, the season is April to August. What is the minimum legal...